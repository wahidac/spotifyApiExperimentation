//
//  Album.m
//  Simple Player
//
//  Created by Wahid Chowdhury on 5/15/14.
//  Copyright (c) 2014 Spotify. All rights reserved.
//

#import "Album.h"
#import "Artist.h"
#import "Track.h"


@implementation Album

@dynamic name;
@dynamic spotifyUrl;
@dynamic artist;
@dynamic tracks;

@end

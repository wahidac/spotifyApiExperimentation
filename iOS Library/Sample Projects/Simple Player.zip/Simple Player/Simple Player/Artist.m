//
//  Artist.m
//  Simple Player
//
//  Created by Wahid Chowdhury on 5/15/14.
//  Copyright (c) 2014 Spotify. All rights reserved.
//

#import "Artist.h"
#import "Album.h"
#import "Track.h"


@implementation Artist

@dynamic name;
@dynamic spotifyUrl;
@dynamic albums;
@dynamic tracks;

@end

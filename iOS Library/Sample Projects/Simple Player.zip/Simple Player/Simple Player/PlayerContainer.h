//
//  PlayerContainer.h
//  Simple Player
//
//  Created by Wahid Chowdhury on 3/14/14.
//  Copyright (c) 2014 Spotify. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PlayerContainer : UIViewController

@end

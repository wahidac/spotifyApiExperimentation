//
//  Track.m
//  Simple Player
//
//  Created by Wahid Chowdhury on 5/15/14.
//  Copyright (c) 2014 Spotify. All rights reserved.
//

#import "Track.h"
#import "Album.h"
#import "Artist.h"


@implementation Track

@dynamic name;
@dynamic spotifyUrl;
@dynamic album;
@dynamic artists;

@end

//
//  PlayerView.h
//  Simple Player
//
//  Created by Wahid Chowdhury on 3/18/14.
//  Copyright (c) 2014 Spotify. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PlayerView : UIView

@property (nonatomic,strong) UISearchBar *searchBar;

@end
